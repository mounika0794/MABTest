package MAB.MABTest;

import java.io.IOException;


import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import MAB.PageObjects.ContactUsPage;
import MAB.Resources.*;


public class RequestACall extends Base{
	
	ContactUsPage contactUsPage;
	


	public RequestACall(){

		super();
	}



	@BeforeMethod
	public void initialize() throws IOException
	{

		initializeDriver();
		contactUsPage=new ContactUsPage();

	}





	@Test
	public void RequestACallBack() throws InterruptedException {



		String name=contactUsPage.validatePageTitle();
		Assert.assertEquals(name,"Contact us | Mortgage Advice Bureau");
		contactUsPage.fillDetails();

	}


	@DataProvider
	public Object[][] getValidData() throws Exception
	{


		Object[][] data = ExcelUtil.getTestData("requestACallData");
		return data;
	}

	@DataProvider
	public Object[][] getInvalidData() throws Exception
	{


		Object[][] data = ExcelUtil.getTestData("invalidData");
		return data;
	}
	
	
	@Test(dataProvider="getValidData")
	public void RequestACallBackDynamic(String fname,String lname,String email,String phn,String bestTime,String reason) throws InterruptedException {



		String name=contactUsPage.validatePageTitle();
		Assert.assertEquals(name,"Contact us | Mortgage Advice Bureau");
		contactUsPage.fillDetailsFromExcel(fname, lname, email, phn, bestTime, reason);

	}

     
	@Test(dataProvider="getInvalidData")
	public void RequestACallInValidDetails(String fname,String lname,String email,String phn) throws InterruptedException {



		String name=contactUsPage.validatePageTitle();
		Assert.assertEquals(name,"Contact us | Mortgage Advice Bureau");
		contactUsPage.fillInValidDetails(fname, lname, email, phn);
		contactUsPage.click();
		String text= contactUsPage.emailValidationError.getText();
		Assert.assertEquals(text, "The Email address field is not a valid e-mail address.");

	}



	@AfterMethod 
	public void afterTear() { 
		driver.close(); 
	}



}
