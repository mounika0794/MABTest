package MAB.PageObjects;


import java.time.Duration;


import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import MAB.Resources.*;


public class ContactUsPage extends Base{
	
	@FindBy(id="FirstName")
	WebElement firstName;
	
	@FindBy(id="LastName")
	WebElement lastName;
	
	@FindBy(id="EmailAddress")
	WebElement email;
	
	@FindBy(id="PhoneNumber")
	WebElement phoneNumber;
	
	
	@FindBy(id="BestTimeToCallYou")
	WebElement bestTime;
	
	@FindBy(id="ReasonForEnquiry")
	WebElement reasonForEnquiry;
	
	@FindBy(xpath="//input[@id='OptInEmail']")
	public WebElement optInEmail;
	
	@FindBy(id="submitMainSiteContactForm")
	WebElement submit;
	
	@FindBy(xpath="//*[@class='field-validation-error']")
	public WebElement emailValidationError;
	

	public ContactUsPage() {
		PageFactory.initElements( driver, this); 
		
	}



	public String validatePageTitle() {
		return driver.getTitle();
	}

	
	public void fillDetails()
	{
		
		
		firstName.sendKeys("ABC");
		lastName.sendKeys("sdf");
		email.sendKeys("abc@gmail.com");
		phoneNumber.sendKeys("0987654321");
		bestTime.sendKeys("1 to 5 PM");
		Select s = new Select(reasonForEnquiry);
		s.selectByVisibleText("Home Mover");
		
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("document.getElementById('OptInEmail').click()");
		
		//optInEmail.click();
	}
	
	public void fillDetailsFromExcel(String fname,String lname,String mailId,String phn,String time,String reason)
	{
		
		
		firstName.sendKeys(fname);
		lastName.sendKeys(lname);
		email.sendKeys(mailId);
		phoneNumber.sendKeys(phn);
		bestTime.sendKeys(time);
		Select s = new Select(reasonForEnquiry);
		s.selectByVisibleText(reason);
		
		/*WebDriverWait wait= new WebDriverWait(driver,Duration.ofSeconds(5));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("OptInEmail")));*/
		
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("document.getElementById('OptInEmail').click()");
		
		//optInEmail.click();
	}
	
	public void fillInValidDetails(String fname,String lname,String mailId,String phn)
	{
		
		
		firstName.sendKeys(fname);
		lastName.sendKeys(lname);
		email.sendKeys(mailId);
		phoneNumber.sendKeys(phn);
		
	}
	
	public void click()
	{
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("document.getElementById('submitMainSiteContactForm').click()");
		//submit.click();
	}
	
	

}
